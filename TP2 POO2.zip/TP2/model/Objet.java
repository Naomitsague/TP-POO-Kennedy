package model;

public class Objet {
    private int id; // Identifiant de la base de données
    private String nom;
    private String description;
    private Proprietaire proprietaire;

    // Constructeur pour créer un objet avec un propriétaire
    public Objet(int id, String nom, String description, Proprietaire proprietaire) {
        this.id = id;
        this.nom = nom;
        this.description = description;
        this.proprietaire = proprietaire;
    }

    // Constructeur sans ID
    public Objet(String nom, String description, Proprietaire proprietaire) {
        this.nom = nom;
        this.description = description;
        this.proprietaire = proprietaire;
    }

    public int getId() {
        return id;
    }

    public String getNom() {
        return nom;
    }

    public String getDescription() {
        return description;
    }

    public Proprietaire getProprietaire() {
        return proprietaire;
    }

    public int getProprietaireId() {
        return proprietaire.getId();
    }

    public void setNom(String nom) {
        this.nom = nom;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public void setProprietaire(Proprietaire proprietaire) {
        this.proprietaire = proprietaire;
    }

    @Override
    public String toString() {
        return "Nom: " + nom + ", Description: " + description + ", Propriétaire: " + proprietaire.getNom();
    }
}