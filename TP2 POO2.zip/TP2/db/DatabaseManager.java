package db;

import model.Proprietaire;

import java.sql.*;

public class DatabaseManager {
    private String url;
    private String user;
    private String password;

    // Constructeur
    public DatabaseManager(String url, String user, String password) {
        this.url = url;
        this.user = user;
        this.password = password;
    }

    // Obtenir une connexion à la base de données
    public Connection getConnection() throws SQLException {
        return DriverManager.getConnection(url, user, password);
    }

    // Insérer un nouveau propriétaire
    public void insertProprietaire(Proprietaire proprietaire, String password) throws SQLException {
        String sql = "INSERT INTO proprietaires (nom, email, password) VALUES (?, ?, ?)";

        try (Connection conn = getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {

            pstmt.setString(1, proprietaire.getNom());
            pstmt.setString(2, proprietaire.getEmail());
            pstmt.setString(3, password);
            pstmt.executeUpdate();

            ResultSet generatedKeys = pstmt.getGeneratedKeys();
            if (generatedKeys.next()) {
                proprietaire.setId(generatedKeys.getInt(1));
            }
        }
    }

    // Récupérer un propriétaire par email et mot de passe
    public Proprietaire getProprietaireByEmailAndPassword(String email, String password) throws SQLException {
        String sql = "SELECT * FROM proprietaires WHERE email = ? AND password = ?";

        try (Connection conn = getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setString(1, email);
            pstmt.setString(2, password);
            ResultSet rs = pstmt.executeQuery();

            if (rs.next()) {
                return new Proprietaire(
                    rs.getInt("id"),
                    rs.getString("nom"),
                    rs.getString("email")
                );
            }
        }

        return null;
    }

    // Insérer un objet volé associé à un propriétaire
    public void insertObjet(String nom, String description, String dateVol, String lieuVol, String numeroSerie, int proprietaireId) throws SQLException {
        String sql = "INSERT INTO objets (nom, description, date_vol, lieu_vol, numero_serie, proprietaire_id) VALUES (?, ?, ?, ?, ?, ?)";

        try (Connection conn = getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setString(1, nom);
            pstmt.setString(2, description);
            pstmt.setDate(3, java.sql.Date.valueOf(dateVol));
            pstmt.setString(4, lieuVol);
            pstmt.setString(5, numeroSerie);
            pstmt.setInt(6, proprietaireId);
            pstmt.executeUpdate();
        }
    }

    // Enregistrer un message de revendication pour un objet volé
    public void ajouterMessageRevendication(int idProprietaire, int idObjet, String message) throws SQLException {
        String sql = "INSERT INTO messages_revendication (id_proprietaire, id_objet, message) VALUES (?, ?, ?)";

        try (Connection conn = getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, idProprietaire);
            stmt.setInt(2, idObjet);
            stmt.setString(3, message);
            stmt.executeUpdate();
        }
    }
}
