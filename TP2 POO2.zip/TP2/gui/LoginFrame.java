package gui;

import javax.swing.*;
import db.DatabaseManager;
import model.Proprietaire;
import java.awt.*;

public class LoginFrame extends JFrame {
    private JTextField emailField;
    private JPasswordField passwordField;

    public LoginFrame() {
        setTitle("Connexion");
        setSize(300, 150);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); // La fenêtre se ferme quand on clique sur la croix
        setLocationRelativeTo(null); // Centre la fenêtre

        emailField = new JTextField(20);
        passwordField = new JPasswordField(20);
        JButton loginButton = new JButton("Connexion");
        JButton signupButton = new JButton("Créer un compte");

        // Action sur le bouton Connexion
        loginButton.addActionListener(e -> {
            String email = emailField.getText();
            String password = new String(passwordField.getPassword());

            DatabaseManager db = new DatabaseManager("jdbc:mysql://localhost:3306/tp2", "root", "");
            try {
                Proprietaire proprietaire = db.getProprietaireByEmailAndPassword(email, password);
                if (proprietaire != null) {
                    System.out.println("Connexion réussie : " + proprietaire.getNom());
                    AccueilFrame accueilFrame = new AccueilFrame(proprietaire);
                    accueilFrame.setVisible(true);
                    dispose(); // Ferme la fenêtre de login après connexion
                } else {
                    JOptionPane.showMessageDialog(this, "Échec de la connexion. Email ou mot de passe incorrect.");
                }
            } catch (Exception ex) {
                ex.printStackTrace();
                JOptionPane.showMessageDialog(this, "Erreur lors de la connexion à la base de données.");
            }
        });

        // Action sur le bouton Créer un compte
        signupButton.addActionListener(e -> new SignupFrame().setVisible(true));

        // Layout
        setLayout(new GridLayout(3, 2));
        add(new JLabel("Email:"));
        add(emailField);
        add(new JLabel("Mot de passe:"));
        add(passwordField);
        add(loginButton);
        add(signupButton);

        // ➕ Important : Affiche la fenêtre !
        setVisible(true);
    }
}
