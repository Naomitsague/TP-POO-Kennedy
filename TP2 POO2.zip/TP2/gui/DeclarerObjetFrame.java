package gui;

import javax.swing.*;
import java.awt.*;
import java.sql.SQLException;

import db.DatabaseManager;
import model.Proprietaire;

public class DeclarerObjetFrame extends JFrame {
    private JTextField nomField;
    private JTextField descriptionField;
    private JTextField dateVolField;
    private JTextField lieuVolField;
    private JTextField numeroSerieField;

    private Proprietaire proprietaire; // pour récupérer l’ID du propriétaire connecté

    public DeclarerObjetFrame(Proprietaire proprietaire) {
        this.proprietaire = proprietaire;

        setTitle("Déclaration d'objet volé");
        setSize(400, 300);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE); // Ne ferme que cette fenêtre
        setLocationRelativeTo(null);

        // Champs de saisie
        nomField = new JTextField(20);
        descriptionField = new JTextField(20);
        dateVolField = new JTextField(20);
        lieuVolField = new JTextField(20);
        numeroSerieField = new JTextField(20);

        JButton soumettreButton = new JButton("Soumettre");

        soumettreButton.addActionListener(e -> {
            String nom = nomField.getText();
            String description = descriptionField.getText();
            String dateVol = dateVolField.getText();
            String lieuVol = lieuVolField.getText();
            String numeroSerie = numeroSerieField.getText();

            DatabaseManager db = new DatabaseManager("jdbc:mysql://localhost:3306/tp2", "root", "");

            try {
                db.insertObjet(nom, description, dateVol, lieuVol, numeroSerie, proprietaire.getId());
                JOptionPane.showMessageDialog(this, "Objet déclaré avec succès !");
                clearFields(); // Réinitialiser les champs pour un nouvel objet
            } catch (SQLException ex) {
                ex.printStackTrace();
                JOptionPane.showMessageDialog(this, "Erreur lors de la déclaration de l'objet.");
            }
        });

        setLayout(new GridLayout(6, 2));
        add(new JLabel("Nom:")); add(nomField);
        add(new JLabel("Description:")); add(descriptionField);
        add(new JLabel("Date du vol (AAAA-MM-JJ):")); add(dateVolField);
        add(new JLabel("Lieu du vol:")); add(lieuVolField);
        add(new JLabel("Numéro de série:")); add(numeroSerieField);
        add(soumettreButton);

        setVisible(true); // Affiche la fenêtre
    }

    private void clearFields() {
        nomField.setText("");
        descriptionField.setText("");
        dateVolField.setText("");
        lieuVolField.setText("");
        numeroSerieField.setText("");
    }
}
