package gui;

import javax.swing.*;
import db.DatabaseManager;
import model.Proprietaire;
import java.awt.*;
import java.sql.SQLException;

public class SignupFrame extends JFrame {
    private JTextField nomField;
    private JTextField emailField;
    private JPasswordField passwordField;

    public SignupFrame() {
        setTitle("Créer un compte");
        setSize(300, 200);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);

        nomField = new JTextField(20);
        emailField = new JTextField(20);
        passwordField = new JPasswordField(20);
        JButton signupButton = new JButton("S'inscrire");

        signupButton.addActionListener(e -> {
            String nom = nomField.getText();
            String email = emailField.getText();
            String password = new String(passwordField.getPassword());

            Proprietaire p = new Proprietaire(nom, email);
            try {
                new DatabaseManager("jdbc:mysql://localhost:3306/tp2", "root", "")
                        .insertProprietaire(p, password);
                JOptionPane.showMessageDialog(this, "Compte créé !");
                dispose();
            } catch (SQLException ex) {
                ex.printStackTrace();
                JOptionPane.showMessageDialog(this, "Erreur : " + ex.getMessage());
            }
        });

        setLayout(new GridLayout(4, 2));
        add(new JLabel("Nom:"));
        add(nomField);
        add(new JLabel("Email:"));
        add(emailField);
        add(new JLabel("Mot de passe:"));
        add(passwordField);
        add(signupButton);
    }
}
