package gui;

import javax.swing.*;
import model.Proprietaire;
import db.DatabaseManager;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;
import java.util.HashMap;

public class AccueilFrame extends JFrame {
    private Proprietaire proprietaire;
    private JComboBox<String> objetComboBox;
    private JTextArea resultArea;
    private JTextArea messageArea;
    private int currentObjetId = -1;
    private HashMap<String, Integer> objetMap = new HashMap<>();

    public AccueilFrame(Proprietaire proprietaire) {
        this.proprietaire = proprietaire;

        setTitle("Accueil");
        setSize(700, 500);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout());

        // --- Bouton déclaration d'objet ---
        JPanel southPanel = new JPanel(new FlowLayout());
        JButton declarerObjetButton = new JButton("Déclarer un objet volé");
        southPanel.add(declarerObjetButton);
        add(southPanel, BorderLayout.SOUTH);

        declarerObjetButton.addActionListener(e -> new DeclarerObjetFrame(proprietaire).setVisible(true));

        // --- Panel recherche ---
        JPanel topPanel = new JPanel(new FlowLayout());
        JTextField searchField = new JTextField(20);
        JButton searchButton = new JButton("Rechercher");
        objetComboBox = new JComboBox<>();
        objetComboBox.addItem("Aucun objet sélectionné");

        topPanel.add(new JLabel("Nom de l'objet :"));
        topPanel.add(searchField);
        topPanel.add(searchButton);
        topPanel.add(objetComboBox);
        add(topPanel, BorderLayout.NORTH);

        // --- Résultats ---
        resultArea = new JTextArea(10, 50);
        resultArea.setEditable(false);
        JScrollPane resultScrollPane = new JScrollPane(resultArea);
        add(resultScrollPane, BorderLayout.CENTER);

        // --- Message de revendication ---
        JPanel rightPanel = new JPanel(new BorderLayout());
        messageArea = new JTextArea(4, 40);
        JButton sendButton = new JButton("Envoyer une revendication");

        rightPanel.add(new JLabel("Message de revendication :"), BorderLayout.NORTH);
        rightPanel.add(new JScrollPane(messageArea), BorderLayout.CENTER);
        rightPanel.add(sendButton, BorderLayout.SOUTH);
        add(rightPanel, BorderLayout.EAST);

        // --- Action recherche ---
        searchButton.addActionListener(e -> {
            String nomObjet = searchField.getText().trim();
            if (nomObjet.isEmpty()) {
                JOptionPane.showMessageDialog(this, "Veuillez entrer un nom d'objet.");
                return;
            }

            objetMap.clear();
            objetComboBox.removeAllItems();
            objetComboBox.addItem("Sélectionnez un objet");
            resultArea.setText("");

            try {
                DatabaseManager db = new DatabaseManager("jdbc:mysql://localhost:3306/tp2", "root", "");
                String sql = "SELECT * FROM objets WHERE nom LIKE ?";
                try (Connection conn = db.getConnection();
                     PreparedStatement pstmt = conn.prepareStatement(sql)) {

                    pstmt.setString(1, "%" + nomObjet + "%");
                    ResultSet rs = pstmt.executeQuery();

                    boolean found = false;
                    StringBuilder resultText = new StringBuilder();

                    while (rs.next()) {
                        found = true;
                        int id = rs.getInt("id");
                        String nom = rs.getString("nom");
                        String description = rs.getString("description");
                        String dateVol = String.valueOf(rs.getDate("date_vol"));
                        String lieuVol = rs.getString("lieu_vol");
                        String numeroSerie = rs.getString("numero_serie");

                        String key = nom + " - " + description;
                        objetMap.put(key, id);
                        objetComboBox.addItem(key);

                        resultText.append("Nom: ").append(nom).append("\n")
                                  .append("Description: ").append(description).append("\n")
                                  .append("Date de vol: ").append(dateVol).append("\n")
                                  .append("Lieu de vol: ").append(lieuVol).append("\n")
                                  .append("Numéro de série: ").append(numeroSerie).append("\n")
                                  .append("------------------------\n");
                    }

                    if (!found) {
                        resultArea.setText("Aucun objet trouvé.");
                        currentObjetId = -1;
                    } else {
                        resultArea.setText(resultText.toString());
                    }
                }
            } catch (Exception ex) {
                ex.printStackTrace();
                resultArea.setText("Erreur lors de la recherche.");
            }
        });

        // --- Sélection d’un objet ---
        objetComboBox.addActionListener(e -> {
            String selected = (String) objetComboBox.getSelectedItem();
            if (selected != null && objetMap.containsKey(selected)) {
                currentObjetId = objetMap.get(selected);
            } else {
                currentObjetId = -1;
            }
        });

  // --- Envoi message ---
sendButton.addActionListener(e -> {
    String message = messageArea.getText().trim();

    try {
        DatabaseManager db = new DatabaseManager("jdbc:mysql://localhost:3306/tp2", "root", "");
        db.ajouterMessageRevendication(proprietaire.getId(), currentObjetId, message);
    } catch (Exception ex) {
        ex.printStackTrace(); 
    }

    JOptionPane.showMessageDialog(this, "Message envoyé !");
    messageArea.setText("");
});


    }
}
